# NHANES Heavy Metals & Disability Analysis — XGBoost Results

## Overview
- **Date**: 2025-10-22 16:29:09
- **Dataset**: NHANES 2011–2016 (Cycles G, H, I)
- **Outcome**: any_disability
- **Model Used**: XGBoost
- **AUC**: 0.7412
- **Training Samples**: 5,775
- **Test Samples**: 1,926
- **Survey Weights**: Applied

## Exported Files
- `xgboost_feature_importance.csv` — feature importances
- `xgboost_predictions.csv` — predicted probabilities
- `roc_curve_xgboost.csv` — ROC data
- `precision_recall_xgboost.csv` — PR curve data
- `calibration_data_xgboost.csv` — calibration data
- `quartile_analysis_LBXBPB.csv` — exposure quartile analysis
- `xgboost_summary.csv` — key statistics summary
