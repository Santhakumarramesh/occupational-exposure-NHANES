# NHANES Heavy Metals & Disability Analysis Results (XGBoost_Cal)

## Analysis Overview
- **Date**: 2025-10-22 16:20:23
- **Dataset**: NHANES 2011–2016 (cycles G, H, I)
- **Outcome**: any_disability
- **Model Used**: XGBoost_Cal (Calibrated)
- **AUC**: 0.7367
- **Training Observations**: 5,775
- **Test Observations**: 1,926

## Exported Files
- `xgboost_cal_performance.csv` – Model performance metrics
- `roc_curve_XGBoost_Cal.csv` – ROC curve coordinates
- `precision_recall_XGBoost_Cal.csv` – Precision–Recall curve data
- `calibration_data_XGBoost_Cal.csv` – Calibration curve data
- `xgboost_cal_feature_importance.csv` – Feature importances
- `xgboost_cal_predictions.csv` – Test set predictions
- `xgboost_cal_analysis_summary.csv` – Summary statistics

### (Optional)
If available:
- `xgboost_cal_quartile_analysis_LBXBPB.csv` – Risk by metal exposure quartiles

## Notes
This report summarizes the calibrated XGBoost model trained on NHANES heavy metals and disability data.
